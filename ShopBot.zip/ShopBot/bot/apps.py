from django.apps import AppConfig


class BotConfig(AppConfig):
    name = 'bot'
    verbose_name = 'Bot'
